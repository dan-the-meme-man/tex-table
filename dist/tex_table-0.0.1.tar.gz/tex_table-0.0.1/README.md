# Tex Table

## Description

This is a simple python script that converts a table in a text file to a tex table.

### Options

TBD
