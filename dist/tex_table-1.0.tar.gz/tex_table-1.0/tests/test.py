import sys
sys.path.append('../src/tex_table/')

import os

print(os.getcwd())

from tex_table import TexTable

# import numpy as np

# from src.tex_table.tex_table import TexTable

# simple_data = np.abs(np.random.normal(0, 0.02, size=(3, 3)))

# table = TexTable(simple_data, options={'round': 4})

# table.interpret_p()

# print(table)

# table.set_option('round', 2)

# print(table)